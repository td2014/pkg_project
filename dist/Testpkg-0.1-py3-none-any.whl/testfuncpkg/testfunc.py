#
# Test function for pip install in Python 3.X environments
#
def testfunc_one():
     print('Running testfunc_one: Python 3.X function for pip install testing.')

     return 'Python 3.X test function result'

#
# End of function
#
